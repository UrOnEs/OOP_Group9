#ifndef BATTERY_H
#define BATTERY_H

/**
 * @class Battery
 * @brief Represents a single battery cell with voltage, capacity, and charge.
 */
class Battery {
protected:
    double voltage;     ///< Voltage in volts [cite: 26]
    double capacity;    ///< Capacity in mAh [cite: 27]
    double charge;      ///< Current charge in mAh [cite: 28]

    static constexpr double DISCHARGE_RATE = 100.0; ///< Fixed discharge rate mAh/hour [cite: 53]
    static constexpr double RECHARGE_RATE = 150.0;  ///< Fixed recharge rate mAh/hour [cite: 54]

public:
    /**
     * @brief Constructor to initialize a Battery object.
     * @param v Voltage in volts.
     * @param c Capacity in mAh.
     * @param initial Initial charge in mAh.
     */
    Battery(double v, double c, double initial);

    /**
     * @brief Virtual destructor.
     */
    virtual ~Battery() {}

    /**
     * @brief Decreases charge based on fixed discharge rate.
     * @param hours Number of hours of usage.
     */
    virtual void use(double hours);

    /**
     * @brief Increases charge based on fixed recharge rate.
     * @param hours Number of hours of recharging.
     */
    virtual void recharge(double hours);

    /**
     * @brief Gets the voltage of the battery.
     * @return Voltage in volts.
     */
    virtual double getVoltage() const;

    /**
     * @brief Gets the capacity of the battery.
     * @return Capacity in mAh.
     */
    virtual double getCapacity() const;

    /**
     * @brief Gets the current charge of the battery.
     * @return Charge in mAh.
     */
    virtual double getCharge() const;

    /**
     * @brief Gets the charge percentage relative to capacity.
     * @return Percentage (0-100).
     */
    virtual double getPercent() const;
};

#endif // BATTERY_H