#include "BatteryPack.h"
#include <algorithm> // for std::min_element
#include <limits>    // for numeric_limits

// Base class initialized with 0s as values are calculated dynamically
BatteryPack::BatteryPack(ConnectionType t) : Battery(0, 0, 0), type(t) {
}

void BatteryPack::add(Battery* b) {
    cells.push_back(b);
}

void BatteryPack::use(double hours) {
    // Simply call each child's method [cite: 79]
    for (Battery* b : cells) {
        b->use(hours);
    }
}

void BatteryPack::recharge(double hours) {
    // Simply call each child's method [cite: 79]
    for (Battery* b : cells) {
        b->recharge(hours);
    }
}

double BatteryPack::getVoltage() const {
    if (cells.empty()) return 0.0;

    if (type == SERIES) {
        // Voltage = sum of all voltages [cite: 71]
        double totalVoltage = 0;
        for (const Battery* b : cells) {
            totalVoltage += b->getVoltage();
        }
        return totalVoltage;
    }
    else { // PARALLEL
        // Voltage = voltage of any cell [cite: 75]
        return cells[0]->getVoltage();
    }
}

double BatteryPack::getCapacity() const {
    if (cells.empty()) return 0.0;

    if (type == SERIES) {
        // Capacity = minimum capacity among cells [cite: 72]
        double minCap = std::numeric_limits<double>::max();
        for (const Battery* b : cells) {
            double cap = b->getCapacity();
            if (cap < minCap) minCap = cap;
        }
        return minCap;
    }
    else { // PARALLEL
        // Capacity = sum of capacities [cite: 76]
        double totalCap = 0;
        for (const Battery* b : cells) {
            totalCap += b->getCapacity();
        }
        return totalCap;
    }
}

double BatteryPack::getCharge() const {
    if (cells.empty()) return 0.0;

    if (type == SERIES) {
        // Charge = minimum charge among cells [cite: 73]
        double minCharge = std::numeric_limits<double>::max();
        for (const Battery* b : cells) {
            double ch = b->getCharge();
            if (ch < minCharge) minCharge = ch;
        }
        return minCharge;
    }
    else { // PARALLEL
        // Charge = sum of charges [cite: 77]
        double totalCharge = 0;
        for (const Battery* b : cells) {
            totalCharge += b->getCharge();
        }
        return totalCharge;
    }
}