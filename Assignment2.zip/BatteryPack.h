#ifndef BATTERYPACK_H
#define BATTERYPACK_H

#include "Battery.h"
#include <vector>

/**
 * @class BatteryPack
 * @brief Represents a pack of batteries connected in Series or Parallel.
 * Inherits from Battery.
 */
class BatteryPack : public Battery {
public:
    /**
     * @brief Connection types for the battery pack.
     */
    enum ConnectionType { SERIES, PARALLEL }; // [cite: 60]

private:
    ConnectionType type;            ///< The type of connection (Series/Parallel)
    std::vector<Battery*> cells;    ///< Collection of pointers to Battery objects [cite: 62]

public:
    /**
     * @brief Constructor for BatteryPack.
     * @param t ConnectionType (SERIES or PARALLEL).
     */
    BatteryPack(ConnectionType t);

    /**
     * @brief Adds a battery to the pack.
     * @param b Pointer to a Battery object.
     */
    void add(Battery* b);

    // Overridden methods [cite: 67-68]

    /**
     * @brief Uses all batteries in the pack.
     * @param hours Duration of usage.
     */
    void use(double hours) override;

    /**
     * @brief Recharges all batteries in the pack.
     * @param hours Duration of recharge.
     */
    void recharge(double hours) override;

    /**
     * @brief Calculates voltage based on connection type.
     * @return Voltage in volts.
     */
    double getVoltage() const override;

    /**
     * @brief Calculates capacity based on connection type.
     * @return Capacity in mAh.
     */
    double getCapacity() const override;

    /**
     * @brief Calculates total charge based on connection type.
     * @return Charge in mAh.
     */
    double getCharge() const override;
};

#endif // BATTERYPACK_H