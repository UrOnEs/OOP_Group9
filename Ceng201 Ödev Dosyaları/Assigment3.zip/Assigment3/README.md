# Group 9

## 👥 Group Members
- Cahit Onur Enoğlu
- Eren Köse
- Hacı Salih Toker
- Yusuf Yücel

### BATTERY SIMULATION SYSTEM WITH GUI
=====================================
## 1. HOW TO COMPILE

This project used Visual Studio 2022 and Qt 6.x for development purposes.
1. Open the "BatteryAssigment31.sln" file using the Visual Studio
2. Verify that the “Qt Visual Studio Tools” extension is installed.
3. Choose "x64" and "Debug" (or Release).
4. Navigate to Build -> Build Solution (Ctrl+Shift+B).

## 2. FEATURES OF THE PROGRAM
----------------------------------
This code satisfies all assignments and possesses additional UI Optimization elements:
* **Battery Design:** The specific Voltage (V) and Capacity (mAh) requirements for battery designs can be entered by the users.
* Pack Assembly: Enables the assembling of cells into SERIES and PARALLEL packs.
* **Simulation:** Allows Use (Discharge) and Recharge operations with real-time updates.
* **Visual Representation:** - Dynamically displays the battery cells on screen. - Uses colors (Green/Orange/Red) to signal charge levels. - Automatically wraps the batteries if the number of cells goes over the width/height of the window. * *Professional UI:* - It includes a custom Dark Theme. - Prioritizes a compact toolbar design to give a professional engineering tool appearance. - Supports a status bar displaying real-time status of the voltage, capacity, and charge.