#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_BatteryAssigment31.h"

class BatteryAssigment31 : public QMainWindow
{
    Q_OBJECT

public:
    BatteryAssigment31(QWidget *parent = nullptr);
    ~BatteryAssigment31();

private:
    Ui::BatteryAssigment31Class ui;
};

