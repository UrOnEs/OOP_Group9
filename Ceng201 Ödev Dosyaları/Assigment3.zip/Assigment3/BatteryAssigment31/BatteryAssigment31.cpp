#include "BatteryAssigment31.h"

BatteryAssigment31::BatteryAssigment31(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
}

BatteryAssigment31::~BatteryAssigment31()
{}

