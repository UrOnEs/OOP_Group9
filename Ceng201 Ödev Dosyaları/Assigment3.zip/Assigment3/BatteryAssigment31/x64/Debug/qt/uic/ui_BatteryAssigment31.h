/********************************************************************************
** Form generated from reading UI file 'BatteryAssigment31.ui'
**
** Created by: Qt User Interface Compiler version 6.10.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_BATTERYASSIGMENT31_H
#define UI_BATTERYASSIGMENT31_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_BatteryAssigment31Class
{
public:
    QWidget *centralWidget;
    QLineEdit *Voltage;
    QComboBox *TypeSelection;
    QLineEdit *Capacity;
    QPushButton *AddBattery;
    QPushButton *CreatePack;
    QPushButton *Use;
    QPushButton *Recharge;
    QDoubleSpinBox *UseAmount;
    QDoubleSpinBox *RechargeAmount;
    QLabel *TotalVoltage;
    QLabel *TotalCapacity;
    QLabel *TotalCharge;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *BatteryAssigment31Class)
    {
        if (BatteryAssigment31Class->objectName().isEmpty())
            BatteryAssigment31Class->setObjectName("BatteryAssigment31Class");
        BatteryAssigment31Class->resize(600, 400);
        centralWidget = new QWidget(BatteryAssigment31Class);
        centralWidget->setObjectName("centralWidget");
        Voltage = new QLineEdit(centralWidget);
        Voltage->setObjectName("Voltage");
        Voltage->setGeometry(QRect(370, 10, 113, 28));
        TypeSelection = new QComboBox(centralWidget);
        TypeSelection->setObjectName("TypeSelection");
        TypeSelection->setGeometry(QRect(40, 80, 82, 28));
        Capacity = new QLineEdit(centralWidget);
        Capacity->setObjectName("Capacity");
        Capacity->setGeometry(QRect(110, 10, 113, 28));
        AddBattery = new QPushButton(centralWidget);
        AddBattery->setObjectName("AddBattery");
        AddBattery->setGeometry(QRect(70, 160, 90, 29));
        CreatePack = new QPushButton(centralWidget);
        CreatePack->setObjectName("CreatePack");
        CreatePack->setGeometry(QRect(210, 160, 90, 29));
        Use = new QPushButton(centralWidget);
        Use->setObjectName("Use");
        Use->setGeometry(QRect(350, 160, 90, 29));
        Recharge = new QPushButton(centralWidget);
        Recharge->setObjectName("Recharge");
        Recharge->setGeometry(QRect(460, 160, 90, 29));
        UseAmount = new QDoubleSpinBox(centralWidget);
        UseAmount->setObjectName("UseAmount");
        UseAmount->setGeometry(QRect(370, 200, 63, 29));
        RechargeAmount = new QDoubleSpinBox(centralWidget);
        RechargeAmount->setObjectName("RechargeAmount");
        RechargeAmount->setGeometry(QRect(470, 200, 63, 29));
        TotalVoltage = new QLabel(centralWidget);
        TotalVoltage->setObjectName("TotalVoltage");
        TotalVoltage->setGeometry(QRect(220, 60, 63, 20));
        TotalCapacity = new QLabel(centralWidget);
        TotalCapacity->setObjectName("TotalCapacity");
        TotalCapacity->setGeometry(QRect(310, 60, 63, 20));
        TotalCharge = new QLabel(centralWidget);
        TotalCharge->setObjectName("TotalCharge");
        TotalCharge->setGeometry(QRect(400, 60, 63, 20));
        BatteryAssigment31Class->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(BatteryAssigment31Class);
        menuBar->setObjectName("menuBar");
        menuBar->setGeometry(QRect(0, 0, 600, 25));
        BatteryAssigment31Class->setMenuBar(menuBar);
        mainToolBar = new QToolBar(BatteryAssigment31Class);
        mainToolBar->setObjectName("mainToolBar");
        BatteryAssigment31Class->addToolBar(Qt::ToolBarArea::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(BatteryAssigment31Class);
        statusBar->setObjectName("statusBar");
        BatteryAssigment31Class->setStatusBar(statusBar);

        retranslateUi(BatteryAssigment31Class);

        QMetaObject::connectSlotsByName(BatteryAssigment31Class);
    } // setupUi

    void retranslateUi(QMainWindow *BatteryAssigment31Class)
    {
        BatteryAssigment31Class->setWindowTitle(QCoreApplication::translate("BatteryAssigment31Class", "BatteryAssigment31", nullptr));
        AddBattery->setText(QCoreApplication::translate("BatteryAssigment31Class", "PushButton", nullptr));
        CreatePack->setText(QCoreApplication::translate("BatteryAssigment31Class", "PushButton", nullptr));
        Use->setText(QCoreApplication::translate("BatteryAssigment31Class", "PushButton", nullptr));
        Recharge->setText(QCoreApplication::translate("BatteryAssigment31Class", "PushButton", nullptr));
        TotalVoltage->setText(QCoreApplication::translate("BatteryAssigment31Class", "TextLabel", nullptr));
        TotalCapacity->setText(QCoreApplication::translate("BatteryAssigment31Class", "TextLabel", nullptr));
        TotalCharge->setText(QCoreApplication::translate("BatteryAssigment31Class", "TextLabel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class BatteryAssigment31Class: public Ui_BatteryAssigment31Class {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_BATTERYASSIGMENT31_H
