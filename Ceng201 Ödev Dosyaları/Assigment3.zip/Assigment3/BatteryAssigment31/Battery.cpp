#include "Battery.h"
#include <algorithm> // for std::min, std::max

Battery::Battery(double v, double c, double initial)
    : voltage(v), capacity(c), charge(initial) {
    // Ensure initial charge is within bounds
    if (charge > capacity) charge = capacity;
    if (charge < 0) charge = 0;
}

void Battery::use(double hours) {
    // Reduces charge by hours * DISCHARGE_RATE [cite: 45]
    charge -= hours * DISCHARGE_RATE;
    if (charge < 0) {
        charge = 0;
    }
}

void Battery::recharge(double hours) {
    // Increases charge by hours * RECHARGE_RATE [cite: 46]
    charge += hours * RECHARGE_RATE;
    if (charge > capacity) {
        charge = capacity;
    }
}

double Battery::getVoltage() const {
    return voltage;
}

double Battery::getCapacity() const {
    return capacity;
}

double Battery::getCharge() const {
    return charge;
}

double Battery::getPercent() const {
    if (capacity == 0) return 0.0;
    return (charge / capacity) * 100.0; // [cite: 50]
}