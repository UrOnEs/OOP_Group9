#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QtWidgets/QMainWindow>
#include <QPushButton>
#include <QLabel>
#include <QSpinBox>
#include <QComboBox>
#include <QVBoxLayout>
#include <QGroupBox> 
#include <vector>
#include "BatteryPack.h"

/**
 * @class MainWindow
 * @brief The main graphical user interface class for the Battery Simulation System.
 * * This class manages the entire lifecycle of the application, including:
 * - User input for battery parameters (Voltage, Capacity).
 * - Assembly of battery packs (Series/Parallel).
 * - Simulation of usage and recharging processes.
 * - Visualization of battery states using QPainter.
 */
class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    /**
     * @brief Constructs the MainWindow.
     * Initializes the window settings and applies the global Qt Style Sheet (QSS).
     * @param parent The parent widget (default is nullptr).
     */
    MainWindow(QWidget* parent = nullptr);

    /**
     * @brief Destructor.
     * Cleans up dynamically allocated memory for the active pack and temporary batteries.
     */
    ~MainWindow();

protected:
    /**
     * @brief Overridden paint event for custom visualization.
     * * Uses QPainter to draw a visual representation of the batteries in the pack.
     * The visualization changes based on the connection type (stacked vertically for Series,
     * horizontally for Parallel) and color-codes the batteries based on charge percentage.
     * * @param event The paint event parameters.
     */
    void paintEvent(QPaintEvent* event) override;

private slots:
    /**
     * @brief Slot for the "Add Cell" button.
     * Reads values from the input fields and adds a new Battery object to the temporary list.
     */
    void onAddBattery();

    /**
     * @brief Slot for the "Assemble Pack" button.
     * Creates a new BatteryPack (Series or Parallel) using the batteries in the temporary list.
     */
    void onCreatePack();

    /**
     * @brief Slot for the "Use" button.
     * Simulates the usage of the active battery pack for a specified duration.
     */
    void onUsePack();

    /**
     * @brief Slot for the "Recharge" button.
     * Simulates the recharging of the active battery pack for a specified duration.
     */
    void onRechargePack();

private:
    // --- UI Components ---

    // Input Fields
    QDoubleSpinBox* spinVolt;   ///< Input widget for defining battery voltage
    QDoubleSpinBox* spinCap;    ///< Input widget for defining battery capacity
    QComboBox* comboType;       ///< Dropdown to select Series or Parallel connection
    QDoubleSpinBox* spinHours;  ///< Input widget for simulation duration (hours)

    // Status & Feedback Labels
    QLabel* lblTempListCount;   ///< Displays how many batteries are waiting to be packed
    QLabel* lblPackStatus;      ///< A styled label displaying the real-time status of the pack

    // --- Data Management ---
    std::vector<Battery*> tempBatteries; ///< Stores pointers to batteries created but not yet packed
    BatteryPack* activePack;             ///< Pointer to the currently active BatteryPack object

    /**
     * @brief Helper function to setup the User Interface.
     * * Creates all widgets, layouts, and groups. It is separated from the constructor
     * to keep the code clean and readable.
     */
    void setupUI();
};

#endif // MAINWINDOW_H