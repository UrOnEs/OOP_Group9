#include "MainWindow.h"
#include <QPainter>
#include <QMessageBox>
#include <QHBoxLayout>
#include <QFrame>

/**
 * @brief Constructor implementation.
 * Sets up the window properties and applies a "Professional Slim" Dark Theme.
 */
MainWindow::MainWindow(QWidget* parent)
    : QMainWindow(parent), activePack(nullptr)
{
    // Set Window Title and size
    setWindowTitle("Battery Simulation System - Pro Edition");
    resize(950, 750); // Geni�li�i biraz art�rd�k ki s��s�n

    // --- PROFESSIONAL SLIM DARK THEME (QSS) ---
    QString style = R"(
        QMainWindow { background-color: #2b2b2b; } 
        QWidget { color: #e0e0e0; font-family: 'Segoe UI', Arial, sans-serif; font-size: 11px; }

        QFrame#ControlPanel {
            background-color: #3c3c3c;
            border-bottom: 1px solid #555;
        }

        /* Compact Inputs */
        QDoubleSpinBox, QComboBox {
            min-height: 22px;
            max-height: 22px;
            padding: 1px 5px;
            border: 1px solid #555;
            border-radius: 3px;
            background-color: #2b2b2b; 
            color: white; 
        }
        
        /* Compact Buttons */
        QPushButton {
            min-height: 22px;
            max-height: 22px;
            background-color: #505050;
            color: white; 
            border: 1px solid #606060;
            border-radius: 3px;
            padding: 0px 15px;
            font-weight: 600;
        }
        QPushButton:hover { background-color: #666666; border: 1px solid #888; }
        QPushButton:pressed { background-color: #404040; }

        QLabel { color: #b0b0b0; font-weight: normal; }
        
        QLabel#StatusLabel {
            color: #00FF00; 
            font-family: Consolas, Monospace;
            font-weight: bold;
        }
    )";

    this->setStyleSheet(style);
    setupUI();
}

MainWindow::~MainWindow() {
    if (activePack) delete activePack;
    for (Battery* b : tempBatteries) {}
}

/**
 * @brief Sets up a "Toolbar" style layout.
 */
void MainWindow::setupUI() {
    QWidget* centralWidget = new QWidget(this);
    setCentralWidget(centralWidget);

    QVBoxLayout* mainLayout = new QVBoxLayout(centralWidget);
    mainLayout->setSpacing(0);
    mainLayout->setContentsMargins(0, 0, 0, 0);

    // --- CONTROL PANEL CONTAINER ---
    QFrame* controlPanel = new QFrame();
    controlPanel->setObjectName("ControlPanel");
    controlPanel->setFixedHeight(80);

    QVBoxLayout* panelLayout = new QVBoxLayout(controlPanel);
    panelLayout->setSpacing(0);
    panelLayout->setContentsMargins(10, 10, 10, 10);

    // --- ROW 1: Configuration ---
    QHBoxLayout* row1 = new QHBoxLayout();
    row1->setSpacing(0);

    // Voltage Group
    row1->addWidget(new QLabel("Voltage:"));
    row1->addSpacing(8);
    spinVolt = new QDoubleSpinBox();
    spinVolt->setSuffix(" V");
    spinVolt->setValue(3.7);
    // G�NCELLEME: Geni�lik art�r�ld� (70 -> 100)
    spinVolt->setFixedWidth(100);
    row1->addWidget(spinVolt);

    row1->addSpacing(25);

    // Capacity Group
    row1->addWidget(new QLabel("Capacity:"));
    row1->addSpacing(8);
    spinCap = new QDoubleSpinBox();
    spinCap->setSuffix(" mAh");
    spinCap->setMaximum(10000);
    spinCap->setValue(2000);
    // G�NCELLEME: Geni�lik art�r�ld� (90 -> 130) "mAh" s��s�n diye
    spinCap->setFixedWidth(130);
    row1->addWidget(spinCap);

    row1->addSpacing(25);

    QPushButton* btnAdd = new QPushButton("Add Cell");
    row1->addWidget(btnAdd);

    row1->addSpacing(20);

    lblTempListCount = new QLabel("Pending: 0");
    lblTempListCount->setStyleSheet("color: orange; font-weight: bold;");
    row1->addWidget(lblTempListCount);

    row1->addStretch();
    panelLayout->addLayout(row1);

    // Vertical space between rows
    panelLayout->addSpacing(5);

    // --- ROW 2: Assembly & Simulation ---
    QHBoxLayout* row2 = new QHBoxLayout();
    row2->setSpacing(0);

    // Type Group
    row2->addWidget(new QLabel("Type:"));
    row2->addSpacing(8);
    comboType = new QComboBox();
    comboType->addItem("Series");
    comboType->addItem("Parallel");
    comboType->setFixedWidth(100); // Biraz daha geni�
    row2->addWidget(comboType);

    row2->addSpacing(15);

    QPushButton* btnCreatePack = new QPushButton("Assemble Pack");
    row2->addWidget(btnCreatePack);

    row2->addSpacing(25);

    // Separator line
    QFrame* line = new QFrame();
    line->setFrameShape(QFrame::VLine);
    line->setFrameShadow(QFrame::Sunken);
    line->setStyleSheet("background-color: #555;");
    row2->addWidget(line);

    row2->addSpacing(25);

    // Simulation Group
    row2->addWidget(new QLabel("Sim Time:"));
    row2->addSpacing(8);
    spinHours = new QDoubleSpinBox();
    spinHours->setSuffix(" h");
    spinHours->setValue(1.0);
    // G�NCELLEME: Geni�lik art�r�ld� (70 -> 100) "h" harfi oka de�mesin diye
    spinHours->setFixedWidth(100);
    row2->addWidget(spinHours);

    row2->addSpacing(15);
    QPushButton* btnUse = new QPushButton("Use");
    row2->addWidget(btnUse);

    row2->addSpacing(10);
    QPushButton* btnCharge = new QPushButton("Recharge");
    row2->addWidget(btnCharge);

    row2->addStretch();
    panelLayout->addLayout(row2);

    // Add Panel to Main Layout
    mainLayout->addWidget(controlPanel);

    // --- STATUS BAR ---
    QHBoxLayout* statusLayout = new QHBoxLayout();
    statusLayout->setContentsMargins(10, 5, 10, 5);

    lblPackStatus = new QLabel("System Ready");
    lblPackStatus->setObjectName("StatusLabel");
    statusLayout->addWidget(lblPackStatus);
    statusLayout->addStretch();

    mainLayout->addStretch();
    mainLayout->addLayout(statusLayout);

    // Connections
    connect(btnAdd, &QPushButton::clicked, this, &MainWindow::onAddBattery);
    connect(btnCreatePack, &QPushButton::clicked, this, &MainWindow::onCreatePack);
    connect(btnUse, &QPushButton::clicked, this, &MainWindow::onUsePack);
    connect(btnCharge, &QPushButton::clicked, this, &MainWindow::onRechargePack);
}

void MainWindow::onAddBattery() {
    double v = spinVolt->value();
    double c = spinCap->value();
    Battery* b = new Battery(v, c, c);
    tempBatteries.push_back(b);
    lblTempListCount->setText(QString("Pending: %1").arg(tempBatteries.size()));
}

void MainWindow::onCreatePack() {
    if (tempBatteries.empty()) {
        QMessageBox::warning(this, "Input Error", "Please add battery cells first.");
        return;
    }
    if (activePack) delete activePack;

    BatteryPack::ConnectionType type = (comboType->currentIndex() == 0) ? BatteryPack::SERIES : BatteryPack::PARALLEL;
    activePack = new BatteryPack(type);

    for (Battery* b : tempBatteries) activePack->add(b);
    tempBatteries.clear();
    lblTempListCount->setText("Pending: 0");

    lblPackStatus->setText(QString("PACK ACTIVE | Type: %1 | Voltage: %2 V | Capacity: %3 mAh | Charge: %4 mAh")
        .arg(type == BatteryPack::SERIES ? "SERIES" : "PARALLEL")
        .arg(activePack->getVoltage()).arg(activePack->getCapacity()).arg(activePack->getCharge()));
    update();
}

void MainWindow::onUsePack() {
    if (!activePack) return;
    activePack->use(spinHours->value());
    lblPackStatus->setText(QString("DISCHARGING | Voltage: %1 V | Capacity: %2 mAh | Charge: %3 mAh")
        .arg(activePack->getVoltage()).arg(activePack->getCapacity()).arg(activePack->getCharge()));
    update();
}

void MainWindow::onRechargePack() {
    if (!activePack) return;
    activePack->recharge(spinHours->value());
    lblPackStatus->setText(QString("RECHARGING | Voltage: %1 V | Capacity: %2 mAh | Charge: %3 mAh")
        .arg(activePack->getVoltage()).arg(activePack->getCapacity()).arg(activePack->getCharge()));
    update();
}

void MainWindow::paintEvent(QPaintEvent* event) {
    QMainWindow::paintEvent(event);

    if (!activePack) return;

    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing);

    // Drawing settings
    int initialX = 20;
    int initialY = 110;

    int currentX = initialX;
    int currentY = initialY;
    int w = 50;
    int h = 90;
    int gap = 15;

    bool isSeries = (comboType->currentIndex() == 0);
    const auto& cells = activePack->getCells();

    // Grid
    QPen gridPen(QColor(60, 60, 60));
    gridPen.setStyle(Qt::DotLine);
    painter.setPen(gridPen);
    for (int i = 0; i < width(); i += 40) painter.drawLine(i, 80, i, height());
    for (int j = 80; j < height(); j += 40) painter.drawLine(0, j, width(), j);

    // Draw Batteries
    for (size_t i = 0; i < cells.size(); ++i) {
        const Battery* b = cells[i];
        double pct = b->getPercent();

        QColor battColor;
        if (pct > 50) battColor.setRgb(46, 204, 113);
        else if (pct > 20) battColor.setRgb(243, 156, 18);
        else battColor.setRgb(231, 76, 60);

        QRect rect(currentX, currentY, w, h);

        // Fill
        int fillHeight = (int)(h * (pct / 100.0));
        int fillY = currentY + (h - fillHeight);

        painter.setBrush(battColor);
        painter.setPen(Qt::NoPen);
        painter.drawRect(currentX + 1, fillY, w - 2, fillHeight);

        // Outline
        painter.setBrush(Qt::NoBrush);
        painter.setPen(QPen(QColor(200, 200, 200), 1));
        painter.drawRect(rect);

        // Text
        painter.setPen(pct > 50 ? Qt::black : Qt::white);
        painter.setFont(QFont("Arial", 9));
        painter.drawText(rect, Qt::AlignCenter, QString::number((int)pct) + "%");

        // Wires
        painter.setPen(QPen(QColor(150, 150, 150), 1));

        if (isSeries) {
            currentY += h + gap;
            if (i < cells.size() - 1 && currentY + h <= height()) {
                painter.drawLine(currentX + w / 2, currentY - gap, currentX + w / 2, currentY);
            }
            if (currentY + h > height() - 30) {
                currentY = initialY;
                currentX += w + gap + 20;
            }
        }
        else {
            currentX += w + gap;
            if (i < cells.size() - 1 && currentX + w <= width()) {
                painter.drawLine(currentX - gap, currentY + h / 2, currentX, currentY + h / 2);
            }
            if (currentX + w > width() - 20) {
                currentX = initialX;
                currentY += h + gap + 20;
            }
        }
    }
}